package �������̽�_����;

import java.util.Random;

public class PlusGame implements IGame{

	Random ran = new Random();
	int num1;
	int num2;
	String[] array = {"+","-","/","*"};
	int c;

	public PlusGame() {
		
	}
	
	public PlusGame(Random ran, int num1, int num2, String[] array, int c) {
		this.ran = ran;
		this.num1 = num1;
		this.num2 = num2;
		this.array = array;
		this.c = c ;
	}

	public void makeRandom() {
		this.num1 = ran.nextInt(9) + 1;
		this.num2 = ran.nextInt(9) + 1;
		this.c = ran.nextInt(4);
	}

	public String getQuizMsg() {
		int tmp;
		if (this.num1 < this.num2) {
			tmp = this.num1;
			this.num1 = this.num2;
			this.num2 = tmp;
		}
		return this.num1 + " " + this.array[c] + " " + this.num2 + " = ";
	}
	
	public boolean checkAnswer(int answer) {
		int tmp;
		if (this.array[c].equals("+")) {
			if (this.num1 + this.num2 == answer) 
				return true;
			else 
				return false;
		}
		else if (this.array[c].equals("-")) {
			if (this.num1 < this.num2) {
				tmp = this.num1;
				this.num1 = this.num2;
				this.num2 = tmp;
			}
			if (this.num1 - this.num2 == answer) 
				return true;
			else 
				return false;
		}
		else if (this.array[c].equals("*")) {
			if (this.num1 * this.num2 == answer) 
				return true;
			else 
				return false;
		}
		else if (this.array[c].equals("/")) {
			if (this.num1 / this.num2 == answer) 
				return true;
			else 
				return false;
		}
		else
			return false;
	}
}
